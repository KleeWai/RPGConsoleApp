﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPG
{
    static class Constants
    {
        public const string NullifyDebuff = "Nullify";
        public const string WeakenDebuff = "Weaken";
        public const string SaveFileName = "NOTASAVEFILE.txt";
    }
}
