﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RPG.weapons
{
    /*class Sword : Weapon
    {
        Level level;
    }*/
}
